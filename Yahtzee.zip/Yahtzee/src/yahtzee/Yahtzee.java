/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yahtzee;

import core.*;
/**
 *
 * @author Jamal
 */
public class Yahtzee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create an instance of class Game
        Game game = new Game();
        //Game is object reference
        game.displayPlayers();
        game.playGame();
     
    
        
        
        
    }
    
}
