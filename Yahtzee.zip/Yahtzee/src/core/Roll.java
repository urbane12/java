/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;
import java.util.ArrayList;

/**
 *
 * @author Jamal
 */
public class Roll {
    
    public ArrayList<Die> dice = new ArrayList();

    /**
     * @return the dice
     */
    public ArrayList<Die> getDice() {
        return dice;
    }

    /**
     * @param dice the dice to set
     */
    public void setDice(ArrayList<Die> dice) {
        this.dice = dice;
    }
    
    public Roll(){
        
        initializeDice();
    }
    private void initializeDice(){
        
        int count;
        for(count = 0; count < 5; count++){
            Die myDie = new Die();
            this.dice.add(myDie);
        }
    }
    public void rollDice(){
        int count;
        for(count=0; count<5; count++)
        {
            dice.get(count).rolldie();
            System.out.print("Die " + (count+1) + " has rolled a value of ");
            System.out.println(dice.get(count).toString());
        }
    }
}
