/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author Jamal
 */
//member variables for game
public class LowerSection {
    private int threeKind;
    private int fourKind;
    private int fullHouse; 
    private int smStraight;
    private int lgStraight; 
    private int yahtzee;
    private int chance; 
    private int yahtzeeBonus;
    private int totalScore; 
//getters and setters
    /**
     * @return the threeKind
     */
    public int getThreeKind() {
        return threeKind;
    }

    /**
     * @param threeKind the threeKind to set
     */
    public void setThreeKind(int threeKind) {
        this.threeKind = threeKind;
    }

    /**
     * @return the fourKind
     */
    public int getFourKind() {
        return fourKind;
    }

    /**
     * @param fourKind the fourKind to set
     */
    public void setFourKind(int fourKind) {
        this.fourKind = fourKind;
    }

    /**
     * @return the fullHouse
     */
    public int getFullHouse() {
        return fullHouse;
    }

    /**
     * @param fullHouse the fullHouse to set
     */
    public void setFullHouse(int fullHouse) {
        this.fullHouse = fullHouse;
    }

    /**
     * @return the smStraight
     */
    public int getSmStraight() {
        return smStraight;
    }

    /**
     * @param smStraight the smStraight to set
     */
    public void setSmStraight(int smStraight) {
        this.smStraight = smStraight;
    }

    /**
     * @return the lgStraight
     */
    public int getLgStraight() {
        return lgStraight;
    }

    /**
     * @param lgStraight the lgStraight to set
     */
    public void setLgStraight(int lgStraight) {
        this.lgStraight = lgStraight;
    }

    /**
     * @return the yahtzee
     */
    public int getYahtzee() {
        return yahtzee;
    }

    /**
     * @param yahtzee the yahtzee to set
     */
    public void setYahtzee(int yahtzee) {
        this.yahtzee = yahtzee;
    }

    /**
     * @return the chance
     */
    public int getChance() {
        return chance;
    }

    /**
     * @param chance the chance to set
     */
    public void setChance(int chance) {
        this.chance = chance;
    }

    /**
     * @return the yahtzeeBonus
     */
    public int getYahtzeeBonus() {
        return yahtzeeBonus;
    }

    /**
     * @param yahtzeeBonus the yahtzeeBonus to set
     */
    public void setYahtzeeBonus(int yahtzeeBonus) {
        this.yahtzeeBonus = yahtzeeBonus;
    }

    /**
     * @return the totalScore
     */
    public int getTotalScore() {
        return totalScore;
    }

    /**
     * @param totalScore the totalScore to set
     */
    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }
}
