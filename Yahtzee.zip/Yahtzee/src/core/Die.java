
package core;
import java.util.Random;
/**
 *
 * @author Jamal
 */
//Grab utility to generate random numbers

public class Die {
   //member varibles 
  private int faceValue;
  private Object string;
  
  //rolldie method definition with instantiation of class random
  public void rolldie()
  {
     Random random = new Random();
        setFaceValue(random.nextInt(6)+1);
     }
     //over ride class object method
    @Override
    public String toString()
    {
        return String.valueOf(getFaceValue());
       
    }
//getters and setters
    /**
     * @return the faceValue
     */
    public int getFaceValue() {
        return faceValue;
    }

    /**
     * @param faceValue the faceValue to set
     */
    public void setFaceValue(int faceValue) {
        this.faceValue = faceValue;
    }

    /**
     * @return the string
     */
    public Object getString() {
        return string;
    }

    /**
     * @param string the string to set
     */
    public void setString(Object string) {
        this.string = string;
    }
    
}


