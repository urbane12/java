/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;
import java.util.*;

/**
 *
 * @author Jamal
 */
public class Player {
    //member variables 
    private String name;
    private ScoreCard score;
    private Roll roll;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the score
     */
    public ScoreCard getScore() {
        return score;
    }

    /**
     * @param score the score to set
     */
    public void setScore(ScoreCard score) {
        this.score = score;
    }

    /**
     * @return the roll
     */
    public Roll getRoll() {
        return roll;
    }

    /**
     * @param roll the roll to set
     */
    public void setRoll(Roll roll) {
        this.roll = roll;
    }
    //override o argument constructor
    public Player()
    {
        roll = new Roll();
    }
    //def of method rooldice
    public void rollDice()
    {
        System.out.println("Player " + name + " rolled:");
        roll.rollDice();
        
    }
    
    
    
}
