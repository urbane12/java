/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.ArrayList;
import java.util.Scanner;
import core.*;

/**
 *
 * @author Jamal
 */
public class Game {
    //creating list of players and input
    private int gameTurn;
    private ArrayList<Player> players = new ArrayList();
    private Scanner input = new Scanner(System.in);
    //creating game
    public Game(){
        System.out.println("How many Players for this game?");
        int numberPlayers = input.nextInt();
        
        int i;
        
        for(i =0; i< numberPlayers; i++){
            newPlayer();
        }
    }
    //creating the player display to show players
    public void displayPlayers(){
        int i;
        
        System.out.println("The players for this game are:");
        
        for(i=0; i<players.size(); i++)
        {
            System.out.println(players.get(i).getName());
            
        }
    }
 
    //
    public void playGame(){
       int i;
        for(i=0; i < players.size(); i++)
    {
            players.get(i).rollDice();
    }
}
    private String data;

    
    
    //new player method to call setter method
    public void newPlayer(){
        System.out.print("Enter player's name: ");
        String inputPlayer = input.next();
        Player myPlayer = new Player();
        myPlayer.setName(inputPlayer);
        this.players.add(myPlayer);
    }

    
    //Getters and setters
    /**
     * @return the gameTurn
     */
    public int getGameTurn() {
        return gameTurn;
    }

    /**
     * @param gameTurn the gameTurn to set
     */
    public void setGameTurn(int gameTurn) {
        this.gameTurn = gameTurn;
    }

    /**
     * @return the players
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }

    /**
     * @param players the players to set
     */
    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    /**
     * @return the input
     */
    public Scanner getInput() {
        return input;
    }

    /**
     * @param input the input to set
     */
    public void setInput(Scanner input) {
        this.input = input;
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }
    

}
