/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package userInterface;

import core.Constants;
import core.Player;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

public class UpperSectionUi extends JPanel
{
    private ArrayList<JButton> categories;
    private ArrayList<JLabel> scores;
    private BoxLayout boxLayout;
    private JLabel total;
    private JLabel bonus;
    private JLabel totalScore;
    private SelectionListener selectionListener;
    private Player player;
    
    public UpperSectionUi()
    {
        initComponents();
    }
    
    private void initComponents()
    {
        boxLayout = new BoxLayout(this, BoxLayout.Y_AXIS);
        
        this.setLayout(boxLayout);
        this.setMinimumSize(new Dimension(500, 300));
        this.setPreferredSize(new Dimension(500, 300));
        this.setMaximumSize(new Dimension(500, 300));
        this.setBorder(BorderFactory.createRaisedBevelBorder());

        categories = new ArrayList<JButton>();
        
        selectionListener = new SelectionListener();
        
        for(int i = 0; i < Constants.MAX_DIE_VALUE; i++)
        {
            JButton category = new JButton();
            category.setMinimumSize(new Dimension(500, 35));
            category.setPreferredSize(new Dimension(500, 35));
            category.setMaximumSize(new Dimension(500, 35));
            category.addActionListener(selectionListener);
            
            switch(i)
            {
                case 0:
                    category.setText(Constants.ACE);
                    category.putClientProperty("category", Constants.ONES);
                    break;
                case 1:
                    category.setText(Constants.TWO);
                    category.putClientProperty("category", Constants.TWOS);
                    break;
                case 2:
                    category.setText(Constants.THREE);
                    category.putClientProperty("category", Constants.THREES);
                    break;
                case 3:
                    category.setText(Constants.FOUR);
                    category.putClientProperty("category", Constants.FOURS);
                    break;
                case 4:
                    category.setText(Constants.FIVE);
                    category.putClientProperty("category", Constants.FIVES);
                    break;
                case 5:
                    category.setText(Constants.SIX);
                    category.putClientProperty("category", Constants.SIXES);
                    break;
                default:
                    break;
            }
            categories.add(category);
        }
              
        totalScore = new JLabel("TOTAL SCORE                                         0");
        totalScore.setMinimumSize(new Dimension(500, 25));
        totalScore.setPreferredSize(new Dimension(500, 25));
        totalScore.setMaximumSize(new Dimension(500, 25));

        bonus = new JLabel();
        bonus.setText(Constants.BONUS);
        bonus.setMinimumSize(new Dimension(500, 25));
        bonus.setPreferredSize(new Dimension(500, 25));
        bonus.setMaximumSize(new Dimension(500, 25));
        
        total = new JLabel("TOTAL of Upper Section                                  0");
        total.setMinimumSize(new Dimension(500, 25));
        total.setPreferredSize(new Dimension(500, 25));
        total.setMaximumSize(new Dimension(500, 25));

        for(JButton category : categories)
        {
            this.add(category);
        }   
        
        this.add(totalScore);
        this.add(bonus);
        this.add(total);
    }

    /**
     * @return the player
     */
    public Player getPlayer() {
        return player;
    }

    /**
     * @param player the player to set
     */
    public void setPlayer(Player player) 
    {
        this.player = player;
    }
    
    public void updateUi()
    {
        int counter = 0;
        
        for(JLabel category : scores)
        {
            switch(counter)
            {
                case 0:
                    category.setText(String.valueOf(player.getScore().getLower().getThreeKind()));
                    break;
                case 1:
                    category.setText(String.valueOf(player.getScore().getLower().getFourKind()));
                    break;
                case 2:
                    category.setText(String.valueOf(player.getScore().getLower().getFullHouse()));
                    break;
                case 3:
                    category.setText(String.valueOf(player.getScore().getLower().getSmallStraight()));
                    break;
                case 4:
                    category.setText(String.valueOf(player.getScore().getLower().getLargeStraight()));
                    break;
                case 5:
                    category.setText(String.valueOf(player.getScore().getLower().getYahtzee()));
                    break;
                case 6:
                    category.setText(String.valueOf(player.getScore().getLower().getYahtzeeBonus()));
                    break;
            }
            counter++;
        }        
    }
    
    private class SelectionListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent ae) 
        {
            int category = 0;

            if(ae.getSource() instanceof JButton)
            {
                JButton button = (JButton)ae.getSource();
                category = (int)button.getClientProperty("category");                
            }            
        }
    }    
}
