/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package yahtzee;

import userInterface.YahtzeeUi;

public class Yahtzee 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        YahtzeeUi yahtzeeUi = new YahtzeeUi();
    }   
}