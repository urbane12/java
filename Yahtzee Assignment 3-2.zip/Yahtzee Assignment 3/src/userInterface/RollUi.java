/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Jamal Galette
 */
public class RollUi extends JPanel{
    //create array list
    ArrayList<JButton> dice = new ArrayList();
    //make roll a jbutton for user
    JButton roll;
    //use the gridlayout for the roll area
    JPanel panel = new JPanel(new GridLayout());
    
    //roll ui
    public RollUi()
        {
           initComponents();
        }
    
    //details of init and set the dimensions
    void initComponents()
    {
       panel.setLayout(new GridLayout(6,3));
       JPanel centerPanel = new JPanel();
       centerPanel.setMinimumSize(new Dimension(275, 400));
       centerPanel.setPreferredSize(new Dimension(275, 400));
       centerPanel.setMaximumSize(new Dimension(275, 400));
       
       //loop through button and dice
       for(int c = 0; c < 5; c++)
        {
        
            JButton jButton = new JButton("" +(c+1));
            this.dice.add(jButton);
            jButton.setPreferredSize(new Dimension(65,75));
            jButton.putClientProperty("dice", (c+1));
            jButton.putClientProperty("isSelected", false);
            jButton.addActionListener(new DiceListener());
            panel.add(dice.get(c));  
        
        }
       
      roll = new JButton("Roll");
       panel.add(roll);
       roll.addActionListener(new RollButtonListener());
       this.add(panel, BorderLayout.CENTER);
      
}


private class RollButtonListener implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
            JOptionPane.showMessageDialog(null, "Rolling the Dice!");
        }
        
      }



private class DiceListener implements ActionListener
{
    
    
    
    public void actionPerformed(ActionEvent e)
    {
        int dice = 0;
        boolean selected = false;
        JFrame frame = new JFrame();
        
        if(e.getSource() instanceof JButton);
            JButton button = (JButton)e.getSource();
            dice = (int)button.getClientProperty("dice");
            
            JOptionPane.showMessageDialog(null, "Selected die was:  " + dice);
            
            selected = (boolean)button.getClientProperty("isSelected");
            
            if(!selected)
                button.putClientProperty("isSelected", true);
            else
                button.putClientProperty("isSelected", false);
            
            JOptionPane.showMessageDialog(null, "Selected Die " + dice + " now " + ((selected) ? "unselected" : "selected"));
        
            }
    
}

}