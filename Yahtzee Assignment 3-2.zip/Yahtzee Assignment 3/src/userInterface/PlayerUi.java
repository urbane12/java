/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Jamal Galette
 */
public class PlayerUi extends JPanel{
    //decale variables
    JLabel playerName;
    JLabel playerScore;
    //set as border layout
    JPanel centerPanel = new JPanel(new GridLayout(1,2));
    
    //calling PlayerUi to run something
    public PlayerUi()
    {
        //calling method to initialize components
        initComponents();
    }
    
    //details of the player section interface with dimensions
    void initComponents()
    {
        
        playerName = new JLabel("Player Name:  ");
        playerScore = new JLabel("Player Score:  ");
        
        centerPanel.setMinimumSize(new Dimension(275, 50));
        centerPanel.setPreferredSize(new Dimension(275, 50));
        centerPanel.setMaximumSize(new Dimension(275, 50));
        centerPanel.setBackground(Color.cyan);
        centerPanel.add(playerName);
        centerPanel.add(playerScore);
        
        //adding to the pane
        this.add(centerPanel);
    }
    
}
 