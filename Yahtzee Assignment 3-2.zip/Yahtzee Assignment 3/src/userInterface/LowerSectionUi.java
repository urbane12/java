/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

//imports
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Jamal Galette
 */

//lower section func to extend JPanel
public class LowerSectionUi extends JPanel{
    
    //use of labels and array organization
    JLabel round;
    ArrayList<JButton> categories = new ArrayList();
    ArrayList<JLabel> scores = new ArrayList();
    
    //make jlabels
    JLabel totalLower;
    JLabel totalUpper;
    JLabel grandTotal;
    //make border
    JPanel panel = new JPanel(new BorderLayout());
     
    //lowersecui to use init
    public LowerSectionUi()
        {
           initComponents();
        }    

    //guts of the initcomp func which adjusts user settings of how the window
    //looks with names
    void initComponents()
    {
    
        totalLower = new JLabel("Total Lower                           0");
        totalUpper = new JLabel("Total Upper                           0");
        grandTotal = new JLabel("Grand Total                           0");
        
        
       JPanel centerPanel = new JPanel();
       centerPanel.setLayout(new GridLayout(11,1));
       centerPanel.setMinimumSize(new Dimension(275, 350));
       centerPanel.setPreferredSize(new Dimension(275, 350));
       centerPanel.setMaximumSize(new Dimension(275, 350));
       //loop through the cases of each possible hand and use a switch statement
       //which decides output to screen
       for(int c = 0; c <= 7; c++)
       {
           JButton jButton = new JButton();
           this.categories.add(jButton);
           
           switch(c){
                           
               case 0:
                      JLabel jLabel = new JLabel("3 of a Kind   Add Score");
                      jButton.setText("3 of a Kind               Add Score");
                      this.scores.add(jLabel);
                      jButton.addActionListener(new GameListener());
                      break;
                      
               case 1:
                      JLabel jLabel1 = new JLabel("4 of a Kind   Add Score");
                      jButton.setText("4 of a Kind               Add Score");
                      this.scores.add(jLabel1);
                      jButton.addActionListener(new GameListener1());
                      break;
                      
               case 2:
                      JLabel jLabel2 = new JLabel("Full House    Score 25");
                      jButton.setText("Full House               Score 25");
                      this.scores.add(jLabel2);
                      jButton.addActionListener(new GameListener2());
                      break;
                      
               case 3:
                      JLabel jLabel3 = new JLabel("Small Straight   Score 30");
                      jButton.setText("Small Straight               Score 30");
                      this.scores.add(jLabel3);
                      jButton.addActionListener(new GameListener3());
                      break;
                      
               case 4:
                      JLabel jLabel4 = new JLabel("Large Straight    Score 40");
                      jButton.setText("Large Straight               Score 40");
                      this.scores.add(jLabel4);
                      jButton.addActionListener(new GameListener4());
                      break;
                      
               case 5:
                      JLabel jLabel5 = new JLabel("Yahtzee          Score 50");
                      jButton.setText("Yahtzee               Score 50");
                      this.scores.add(jLabel5);
                      jButton.addActionListener(new GameListener5());
                      break;
                      
               case 6:
                      JLabel jLabel6 = new JLabel("Chance   Score Total Of All 5 Dice");
                      jButton.setText("Chance      Score Total of All 5 Dice");
                      this.scores.add(jLabel6);
                      jButton.addActionListener(new GameListener6());
                      break;
                      
               case 7:
                      JLabel jLabel7 = new JLabel("Yahtzee Bonus   Score 100");
                      jButton.setText("Yahtzee Bonus               Score 100");
                      this.scores.add(jLabel7);
                      jButton.addActionListener(new GameListener7());
                      break;
                      
           }    
           
           
       centerPanel.add(categories.get(c));    
       }
       //System.out.println("gottem");
      
       centerPanel.add(totalUpper);
       centerPanel.add(totalLower);
       centerPanel.add(grandTotal);
       this.add(centerPanel);
    }
    private class GameListener implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
       
             JOptionPane.showMessageDialog(null, "You have selected 3 of a kind!");
        
        }
        
      }    
        
      private class GameListener1 implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
             JOptionPane.showMessageDialog(null, "You have selected 4 of a Kind!");
        
        } 
        
      }
      
      private class GameListener2 implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
             JOptionPane.showMessageDialog(null, "You have selected Full House!");
        
        } 
        
      }
      
      private class GameListener3 implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
             JOptionPane.showMessageDialog(null, "You have selected Small Straight!");
        
        } 
        
      }
      
      private class GameListener4 implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
            
             JOptionPane.showMessageDialog(null, "You have selected Large Straight!");
        
        } 
        
      }
      
      private class GameListener5 implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
             JOptionPane.showMessageDialog(null, "You have selected Yahtzee!");
        
        } 
        
      }
    
      private class GameListener6 implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
             JOptionPane.showMessageDialog(null, "You have selected Chance!");
        
        } 
        
      }
      
      private class GameListener7 implements ActionListener
      {
        
        public void actionPerformed(ActionEvent e)
        {
             JOptionPane.showMessageDialog(null, "You have selected Yahtzee Bonus!");
        
        } 
        
      }
}


