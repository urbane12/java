/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;
//imports
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 *
 * @author Jamal Galette
 */
public class YahtzeeUi {
    
    //create variables
    GameUi gameUi;
    PlayerUi playerUi;
    RollUi rollUi;
    ScoreCardUi scoreCardUi;
    JFrame frame;
    JMenuItem exit;    
    JMenuBar menuBar;
    JMenu game = new JMenu();
    JMenuItem newGame;
    JPanel rightPanel;
    JPanel leftPanel;
    
    //use the border layout
    BorderLayout mainPane = new BorderLayout();
    
    public YahtzeeUi()
    {
        initComponents();
    }
    
    void initComponents()
    {
        //set the frames to organize
        frame = new JFrame();
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Yahtzee!");
        frame.setLayout(mainPane);
        frame.setMinimumSize(new Dimension(700, 700));
        frame.setPreferredSize(new Dimension(700, 700));
        frame.setMaximumSize(new Dimension(700, 700));
        
        
        //set menu
         menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);
        game = new JMenu("Game");
        menuBar.add(game);
        
        //add event handlers
        newGame = new JMenuItem("New Game");
        newGame.addActionListener(new GameListener());
        game.add(newGame);
        //add exit to menu
        exit = new JMenuItem("Exit");
        exit.addActionListener(new ExitListener());
        game.add(exit);
        
        gameUi = new GameUi();
        playerUi = new PlayerUi();
        rollUi = new RollUi();
        //make the right side section panel with dimensions
        rightPanel = new JPanel();
        rightPanel.setMinimumSize(new Dimension(275, 675));
        rightPanel.setPreferredSize(new Dimension(275, 675));
        rightPanel.setMaximumSize(new Dimension(275, 675));
        rightPanel.add(gameUi);
        rightPanel.add(playerUi);
        rightPanel.add(rollUi);
        
        //make score card
        scoreCardUi = new ScoreCardUi();
        //set right frame
        frame.add(rightPanel, BorderLayout.EAST);
        
        //make the left side panel sections and dimesions 
        leftPanel = new JPanel();
        leftPanel.setMinimumSize(new Dimension(275, 575));
        leftPanel.setPreferredSize(new Dimension(275, 575));
        leftPanel.setMaximumSize(new Dimension(275, 575));
        leftPanel.add(scoreCardUi);
        
        //adding left panel to frame
        frame.add(leftPanel, BorderLayout.WEST);
        
        //setting frame to visible so it can be seen
        frame.setVisible(true);
                
    }
     private class ExitListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            int response = JOptionPane.showConfirmDialog(null, "Confirm to exit Yahtzee?", 
                    "Exit", JOptionPane.YES_NO_OPTION);
            
            if (response == JOptionPane.YES_OPTION)
                System.exit(0);	
        }	
    }
    
    private class GameListener implements ActionListener
    {
        
        public void actionPerformed(ActionEvent e)
        {
             int response = JOptionPane.showConfirmDialog(null, "Do you want to start a new game?", 
                    "Select an option", JOptionPane.YES_NO_CANCEL_OPTION);
        }
    }
}
