/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//imports
package userInterface;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.*;

/**
 *
 * @author Jamal Galette
 */

//GameUi func to extend JPanel
public class GameUi extends JPanel {
    
   
//Make variables a JLabel for user
    JLabel round;
    JLabel gameTurn;
    JLabel logo;
    
    //create border
    JPanel centerPanel = new JPanel();
  
    //GameUi func to use intitcomp
        public GameUi()
        {
            initComponents();
        }
        //initcomp func
    void initComponents(){
    
        //add label details to previously intialized JLabels
        round = new JLabel("Yahtzee          0/13");
        gameTurn = new JLabel("Name              0");
        logo = new JLabel("Yahtzee!!!");
       
        //create dimensions for the user interface setting, max/min 
       centerPanel.setLayout(new GridLayout(1,2));
       centerPanel.setMinimumSize(new Dimension(275, 100));
       centerPanel.setPreferredSize(new Dimension(275, 100));
       centerPanel.setMaximumSize(new Dimension(275, 100));
       centerPanel.setBackground(Color.cyan);
       centerPanel.add(round);
       centerPanel.add(gameTurn);
       this.add(centerPanel);
       
       
       
    }           
      
}
    
    
