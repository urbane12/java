/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author Jamal Galette
 */
public class Player {
    
    //declare variables used
    private String name;
    private ScoreCard score;
    private Roll roll;

   //getters setterd
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ScoreCard getScore() {
        return score;
    }

    public void setScore(ScoreCard score) {
        this.score = score;
    }

    public Roll getRoll() {
        return roll;
    }

    public void setRoll(Roll roll) {
        this.roll = roll;
    }
    
   public Player()
   {
       // setting up roll dice
       roll = new Roll();
   }
    //roll dice func and print out name
    public void rollDice()
    {
        
        System.out.println("player " + name);
        roll.rollDice();
    }
}
