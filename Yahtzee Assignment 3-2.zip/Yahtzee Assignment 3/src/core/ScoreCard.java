/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;



/**
 *
 * @author Jamal Galette
 */

//scorecard func
public class ScoreCard {
    
    private UpperSection upper;
    private LowerSection lower;
    private int grandtotal;

    //get upper func
    public UpperSection getUpper() {
        return upper;
    }
    //set upper
    public void setUpper(UpperSection upper) {
        this.upper = upper;
    }
    //get lower func
    public LowerSection getLower() {
        return lower;
    }
    //set lower func
    public void setLower(LowerSection lower) {
        this.lower = lower;
    }

        //get grand func
    public int getGrandtotal() {
        return grandtotal;
    }

    //set the grand func
    public void setGrandtotal(int grandtotal) {
        this.grandtotal = grandtotal;
    }
    
}
