/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.Random;

/**
 *
 * @author Jamal Galette
 */
public class Die {
    
    //declaring faceValue and string variables
    private int faceValue;
    private Object string;
    
    public void rollDie()
    {
       //making a random number 1-6
        Random random = new Random();
        setFaceValue(1 + random.nextInt(6));
        
        
    }

    /**
     * @return the faceValue
     */
    public int getFaceValue() {
        return faceValue;
    }

    /**
     * @param faceValue the faceValue to set
     */
    public void setFaceValue(int faceValue) {
        this.faceValue = faceValue;
    }
    
   //overriding interger to string
    @Override
    public String toString(){
        return String.format("%d", faceValue);
}
}