/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

//imports
import java.util.ArrayList;
import java.util.Scanner;
import core.*;

/**
 *
 * @author Jamal Galette
 */
public class Game {
    
    //declaration of variables used
    private int gameTurn;
    private ArrayList<Player> players = new ArrayList();
    private Scanner input = new Scanner(System.in);

    /**
     * @return the gameTurn
     */
    public int getGameTurn() {
        return gameTurn;
    }

    /**
     * @param gameTurn gameTurn to set
     */
    public void setGameTurn(int gameTurn) {
        this.gameTurn = gameTurn;
    }

    /**
     * @return the players
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }

    /**
     * @param players players to set
     */
    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    /**
     * @return the input
     */
    public Scanner getInput() {
        return input;
    }

    /**
     * @param input input to set
     */
    public void setInput(Scanner input) {
        this.input = input;
    }
    

public Game()
{   
    //figure ow how many players their is and calling function
    System.out.println("How many players are there for this game?");
    int numberPlayers = input.nextInt();
    
    int i;
    
    for(i = 0; i < numberPlayers; i++)
    {
        newPlayer();    
    }
    //blank line
    System.out.println("");
}

    /**
     *
     */
    public void newPlayer()
{
    //figure out player identifiers aka names
    System.out.print("Enter player's name:  ");
    String inputPlayer = input.next();
    Player myplayer = new Player();
    myplayer.setName(inputPlayer);
    this.players.add(myplayer);
    
}

    /**
     *
     */
  
    public void displayPlayers()
{
    //count
    int c;
    
    //printing players for the game
    System.out.println("Players for this game are:");
    
    //looping through array players
    for(c = 0; c < players.size(); c++)
    {
        //printing players
        System.out.println(players.get(c).getName());
        
    }
    
    //printing empty line
    System.out.println("");
}

    /**
     *
     */
    public void playGame()
{
    //counter
    int c;
    
    //loop through players and roll dice
    for (c=0; c < players.size(); c++)
    {
    
    //printing players, dice and new line
    players.get(c).rollDice();
    System.out.println("");    
    
    }
    
}

}