/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//imports and package
package core;

import java.util.ArrayList;

/**
 *
 * @author Jamal Galette
 */
 
public class Roll {

    //dice array func get/set dice
    public ArrayList<Die> getDice() {
        return dice;
    }

    public void setDice(ArrayList<Die> dice) {
        this.dice = dice;
    }
    //roll func
    public Roll ()
    {
        //call intilization of the dice
        initializeDice();
    }
    public ArrayList<Die> dice = new ArrayList();
    
    
    //int. dice func
private void initializeDice()
    {
        //count
       int c;
       
       //looping through 5 dice
       for(c = 0; c < 5; c++){
        
           //making the new dice and using 
            Die die = new Die();
            this.dice.add(die);
               
    }
    }

//roll dice funct to loop through rolls and number and also print
public void rollDice()
{
    //count
    int c;
    
    //looping through rolls for each dice
    for(c = 0; c <5; c++)
    {
    //printing the roll for the dice number     
    dice.get(c).rollDie();
    System.out.print("Die " + (c+1) + " has rolled a value of ");
    System.out.println(dice.get(c).toString());
    }
}

}
