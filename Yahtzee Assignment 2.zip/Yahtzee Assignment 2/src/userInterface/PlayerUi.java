/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Jamal Galette
 */
public class PlayerUi extends JPanel{
    //decale variables
    JLabel playerName;
    JLabel playerScore;
    //set as border layout
    JPanel panel = new JPanel(new BorderLayout());
    
    //details of the player section interface with dimensions
    void initComponents()
    {
        
        playerName = new JLabel("Player Name:  ");
        playerScore = new JLabel("Player Score:  ");
        
        JPanel centerPanel = new JPanel();   
        centerPanel.setMinimumSize(new Dimension(150, 70));
        centerPanel.setPreferredSize(new Dimension(150, 70));
        centerPanel.setMaximumSize(new Dimension(150, 70));
        centerPanel.add(playerName);
        centerPanel.add(playerScore);
        //make use of central panel
        this.add(centerPanel);
    }
    
}
