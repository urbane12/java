/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.JButton;


/**
 *
 * @author Jamal Galette
 */
public class UpperSectionUi extends JPanel{
    
    //create array list for categories and scores
    ArrayList<JButton> categories = new ArrayList();
    ArrayList<JLabel> scores = new ArrayList();
    
    //make total bonus and totalscore a label 
    JLabel total;
    JLabel bonus;
    JLabel totalScore;
    
    public UpperSectionUi()
    {
        initComponents();
    }
    
    //create init
    void initComponents()
    {
        //gives names to labels
        total = new JLabel("Total                                           0");
        bonus = new JLabel("Bonus                         If Score is Over 63");
        totalScore = new JLabel("Total Score:                                0");
        //dimensions and use center panel
       JPanel centerPanel = new JPanel();
       centerPanel.setLayout(new GridLayout(10,1));
       centerPanel.setMinimumSize(new Dimension(275, 300));
       centerPanel.setPreferredSize(new Dimension(275, 300));
       centerPanel.setMaximumSize(new Dimension(275, 300));
       
       //loop for categories case and decide which with a switch
       for(int c = 0; c < 6; c++)
       {
       JButton jButton = new JButton();
      
       this.categories.add(jButton);
           switch(c){
                           
               case 0:{
                      JLabel jLabel = new JLabel("Aces     Count and add only Aces");
                      jButton.setText("Aces     Count and add only Aces");
                      this.scores.add(jLabel);
                      break;
                      }
               case 1:{
                      JLabel jLabel = new JLabel("Twos     Count and add only Twos");
                      jButton.setText("Twos   Count and add only Twos");
                      this.scores.add(jLabel);
                      break;
                      }
               case 2:{
                      JLabel jLabel = new JLabel("Threes    Count and add only Threes");
                      jButton.setText("Threes      Count and add only Threes");
                      this.scores.add(jLabel);
                      break;
                      }
               case 3:{
                      JLabel jLabel = new JLabel("Fours     Count and add only Fours");
                      jButton.setText("Fours   Count and add only Fours");
                      this.scores.add(jLabel);
                      break;
                      }
               case 4:{
                      JLabel jLabel = new JLabel("Fives     Count and add only Fives");
                      jButton.setText("Fives   Count and add only Fives");
                      this.scores.add(jLabel);
                      break;
                      }
               case 5:{
                      JLabel jLabel = new JLabel("Sixes     Count and add only Sixes");
                      jButton.setText("Sixes   Count and add only Sixes");
                      this.scores.add(jLabel);
                      break;
                      }
              
           }
           
        
       
       //add sections
       centerPanel.add(categories.get(c));    
       }
       centerPanel.add(total);
       centerPanel.add(bonus);
       centerPanel.add(totalScore);
       this.add(centerPanel);
       
        
    }
    
}
