/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Jamal Galette
 */
public class ScoreCardUi extends JPanel{
    
    //make grandtotal a label
    JLabel grandTotal;
    //create lower and upper
    LowerSectionUi lowerUi = new LowerSectionUi();
    UpperSectionUi upperUi = new UpperSectionUi();
    
    //use of border desgin layout
    JPanel panel = new JPanel(new BorderLayout());  
     
    //scorecard creation
 public ScoreCardUi()
 {
    
    initComponents();
    
}   
    
    void initComponents(){
        //use jpanel
       JPanel centerPanel = new JPanel();
       //user box dimesions
       centerPanel.setMinimumSize(new Dimension(275, 700));
       centerPanel.setPreferredSize(new Dimension(275, 700));
       centerPanel.setMaximumSize(new Dimension(275, 700));
       //use center panel
       centerPanel.add(upperUi);
       centerPanel.add(lowerUi);
       this.add(centerPanel);
        
    }
}
