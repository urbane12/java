/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;
//imports
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.*;


/**
 *
 * @author Jamal Galette
 */
public class YahtzeeUi {
    
    //create variables
    GameUi gameUi;
    PlayerUi playerUi;
    RollUi rollUi;
    ScoreCardUi scoreCardUi;
    JFrame frame;
    JMenuItem exit;    
    JMenuBar menuBar;
    JMenu game = new JMenu();
    JMenuItem newGame;
    JPanel rightPanel;
    JPanel leftPanel;
    
    //use the border layout
    BorderLayout mainPane = new BorderLayout();
    
    public YahtzeeUi()
    {
        initComponents();
    }
    
    void initComponents()
    {
        //set the frames to organize
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Yahtzee!");
        frame.setLayout(mainPane);
        frame.setMinimumSize(new Dimension(700, 750));
        frame.setPreferredSize(new Dimension(700, 750));
        frame.setMaximumSize(new Dimension(700, 750));
        
        
        
        frame.setJMenuBar(menuBar);
        
        gameUi = new GameUi();
        playerUi = new PlayerUi();
        rollUi = new RollUi();
        //make the right side section panel with dimensions
        rightPanel = new JPanel();
        rightPanel.setMinimumSize(new Dimension(275, 675));
        rightPanel.setPreferredSize(new Dimension(275, 675));
        rightPanel.setMaximumSize(new Dimension(275, 675));
        rightPanel.add(gameUi);
        rightPanel.add(playerUi);
        rightPanel.add(rollUi);
        
        scoreCardUi = new ScoreCardUi();
        
        frame.add(rightPanel, BorderLayout.EAST);
        
        //make the left side panel sections and dimesions 
        leftPanel = new JPanel();
        leftPanel.setMinimumSize(new Dimension(275, 575));
        leftPanel.setPreferredSize(new Dimension(275, 575));
        leftPanel.setMaximumSize(new Dimension(275, 575));
        leftPanel.add(scoreCardUi);
        
        frame.add(leftPanel, BorderLayout.WEST);
        frame.setVisible(true);
                
    }
    
}
