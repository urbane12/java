/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Jamal Galette
 */
public class RollUi extends JPanel{
    //create array list
    ArrayList<JButton> dice = new ArrayList();
    //make roll a jbutton for user
    JButton roll;
    //use the gridlayout for the roll area
    JPanel panel = new JPanel(new GridLayout());
    
    //roll ui
    public RollUi()
        {
           initComponents();
        }
    
    //details of init and set the dimensions
    void initComponents()
    {
       panel.setLayout(new GridLayout(6,3));
       JPanel centerPanel = new JPanel();
       centerPanel.setMinimumSize(new Dimension(275, 400));
       centerPanel.setPreferredSize(new Dimension(275, 400));
       centerPanel.setMaximumSize(new Dimension(275, 400));
       
       //loop through button and dice
       for(int c = 0; c < 5; c++)
        {
        
            JButton jButton = new JButton("" +(c+1));
            this.dice.add(jButton);
            jButton.setPreferredSize(new Dimension(85,85));
            panel.add(dice.get(c));  
        
        }
       
       //create and use roll, panel
       roll = new JButton("Roll");
       panel.add(roll);
       this.add(panel, BorderLayout.CENTER);
      
}
}